from django.contrib import admin
from recSys.models import *
# Register your models here.


admin.site.register(Movie)
admin.site.register(Love)
admin.site.register(ExtUser)
admin.site.register(Comment)
